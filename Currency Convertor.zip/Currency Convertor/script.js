const amountInput = document.getElementById('amount');
const fromCurrencySelect = document.getElementById('from-currency');
const toCurrencySelect = document.getElementById('to-currency');
const convertButton = document.getElementById('convert');
const resultText = document.getElementById('result-text');

const apiUrl = 'https://v6.exchangerate-api.com/v6/98635b6944e8a52a46eebb4c/latest/USD';

async function loadCurrencies() {
    try {
        const response = await fetch(apiUrl);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();

        const currencies = Object.keys(data.conversion_rates);

        // Clear previous options
        fromCurrencySelect.innerHTML = '';
        toCurrencySelect.innerHTML = '';

        // Populate dropdowns
        currencies.forEach(currency => {
            const optionFrom = document.createElement('option');
            optionFrom.value = currency;
            optionFrom.textContent = currency;
            fromCurrencySelect.appendChild(optionFrom);

            const optionTo = document.createElement('option');
            optionTo.value = currency;
            optionTo.textContent = currency;
            toCurrencySelect.appendChild(optionTo);
        });

        // Set default values if needed
        fromCurrencySelect.value = 'USD';
        toCurrencySelect.value = 'USD';

    } catch (error) {
        console.error('Error fetching currencies:', error);
    }
}

async function convertCurrency() {
    const amount = parseFloat(amountInput.value);
    const fromCurrency = fromCurrencySelect.value;
    const toCurrency = toCurrencySelect.value;

    if (isNaN(amount) || amount <= 0) {
        alert('Please enter a valid amount');
        return;
    }

    try {
        const response = await fetch(apiUrl);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();
        const rateFromBase = data.conversion_rates[toCurrency] / data.conversion_rates[fromCurrency];
        const result = amount * rateFromBase;
        resultText.textContent = `${amount} ${fromCurrency} = ${result.toFixed(2)} ${toCurrency}`;
    } catch (error) {
        console.error('Error converting currency:', error);
        resultText.textContent = 'Conversion rate not available.';
    }
}

convertButton.addEventListener('click', convertCurrency);
window.addEventListener('load', loadCurrencies);
