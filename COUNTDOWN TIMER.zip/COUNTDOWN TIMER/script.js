document.getElementById('countdown-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const targetDateInput = document.getElementById('target-date').value;
    const targetDate = new Date(targetDateInput);

    if (isNaN(targetDate.getTime())) {
        alert('Please enter a valid date and time.');
        return;
    }

    function updateTimer() {
        const now = new Date();
        const timeRemaining = targetDate - now;

        if (timeRemaining <= 0) {
            document.getElementById('days').textContent = '0 Days';
            document.getElementById('hours').textContent = '0 Hours';
            document.getElementById('minutes').textContent = '0 Minutes';
            document.getElementById('seconds').textContent = '0 Seconds';
            return;
        }

        const days = Math.floor(timeRemaining / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeRemaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((timeRemaining % (1000 * 60)) / 1000);

        document.getElementById('days').textContent = `${days} Days`;
        document.getElementById('hours').textContent = `${hours} Hours`;
        document.getElementById('minutes').textContent = `${minutes} Minutes`;
        document.getElementById('seconds').textContent = `${seconds} Seconds`;
    }

    updateTimer();
    setInterval(updateTimer, 1000);
});
